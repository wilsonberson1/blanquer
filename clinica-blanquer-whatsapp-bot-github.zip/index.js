/**
 * Clínica Blanquer - WhatsApp Bot (Cloud API Meta)
 * Menu: 1-Agendar / 2-Atendente / 3-Localização
 * Fuso: America/Sao_Paulo
 * Notificações: E-mail (SMTP) e Slack (webhook)
 * Google Calendar: opcional (OAuth2 refresh token OU Service Account)
 *
 * Variáveis de ambiente obrigatórias:
 *   WHATSAPP_TOKEN, PHONE_ID, VERIFY_TOKEN, PORT
 * Opcionais úteis:
 *   FROM_EMAIL, TO_EMAIL, SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS
 *   SLACK_WEBHOOK_URL
 *   CALENDAR_ID + (GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REFRESH_TOKEN) OU SERVICE_ACCOUNT_KEY
 */

const express = require("express");
const axios = require("axios");
const bodyParser = require("body-parser");
const { google } = require("googleapis");
const dayjs = require("dayjs");
const utc = require("dayjs/plugin/utc");
const timezone = require("dayjs/plugin/timezone");
const nodemailer = require("nodemailer");

dayjs.extend(utc);
dayjs.extend(timezone);
const DEFAULT_TZ = "America/Sao_Paulo";

const app = express();
app.use(bodyParser.json());

// ENV
const WHATSAPP_TOKEN = process.env.WHATSAPP_TOKEN;
const VERIFY_TOKEN   = process.env.VERIFY_TOKEN || "blanquer123";
const PHONE_ID       = process.env.PHONE_ID;
const PORT           = process.env.PORT || 3000;

const FROM_EMAIL     = process.env.FROM_EMAIL;
const TO_EMAIL       = process.env.TO_EMAIL;
const SMTP_HOST      = process.env.SMTP_HOST;
const SMTP_PORT      = Number(process.env.SMTP_PORT || 587);
const SMTP_USER      = process.env.SMTP_USER;
const SMTP_PASS      = process.env.SMTP_PASS;
const SLACK_WEBHOOK_URL = process.env.SLACK_WEBHOOK_URL;

const CALENDAR_ID    = process.env.CALENDAR_ID || process.env.GOOGLE_CALENDAR_ID;
const SERVICE_ACCOUNT_KEY = process.env.SERVICE_ACCOUNT_KEY;
const GOOGLE_CLIENT_ID     = process.env.GOOGLE_CLIENT_ID;
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;
const GOOGLE_REFRESH_TOKEN = process.env.GOOGLE_REFRESH_TOKEN;

if (!WHATSAPP_TOKEN || !PHONE_ID) {
  console.warn("ATENÇÃO: defina WHATSAPP_TOKEN e PHONE_ID nas variáveis de ambiente.");
}

// Helpers -------------------------
async function sendText(to, text) {
  try {
    await axios.post(
      `https://graph.facebook.com/v20.0/${PHONE_ID}/messages`,
      { messaging_product: "whatsapp", to, type: "text", text: { body: text } },
      { headers: { Authorization: `Bearer ${WHATSAPP_TOKEN}` } }
    );
  } catch (err) {
    console.error("Erro ao enviar mensagem:", err.response?.data || err.message);
  }
}

async function notifySlack(text) {
  if (!SLACK_WEBHOOK_URL) return;
  try {
    await axios.post(SLACK_WEBHOOK_URL, { text });
  } catch (err) {
    console.error("Erro Slack:", err.response?.data || err.message);
  }
}

async function sendEmail(subject, text) {
  if (!FROM_EMAIL || !TO_EMAIL || !SMTP_HOST || !SMTP_USER || !SMTP_PASS) return;
  try {
    const transporter = nodemailer.createTransport({
      host: SMTP_HOST,
      port: SMTP_PORT,
      secure: false,
      auth: { user: SMTP_USER, pass: SMTP_PASS }
    });
    await transporter.sendMail({ from: FROM_EMAIL, to: TO_EMAIL, subject, text });
  } catch (err) {
    console.error("Erro e-mail:", err.message);
  }
}

// Google Calendar ----------------
async function getGoogleAuthClient() {
  if (SERVICE_ACCOUNT_KEY) {
    const key = JSON.parse(SERVICE_ACCOUNT_KEY);
    const scopes = ["https://www.googleapis.com/auth/calendar"];
    const { JWT } = require("google-auth-library");
    const client = new JWT({ email: key.client_email, key: key.private_key, scopes });
    await client.authorize();
    return client;
  }
  if (GOOGLE_CLIENT_ID && GOOGLE_CLIENT_SECRET && GOOGLE_REFRESH_TOKEN) {
    const { OAuth2 } = require("google-auth-library");
    const oAuth2 = new OAuth2(GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET);
    oAuth2.setCredentials({ refresh_token: GOOGLE_REFRESH_TOKEN });
    return oAuth2;
  }
  throw new Error("Credenciais Google ausentes (use SERVICE_ACCOUNT_KEY ou OAuth2).");
}

async function createCalendarEvent({ summary, description, startDateTime, endDateTime, attendees = [] }) {
  if (!CALENDAR_ID) throw new Error("CALENDAR_ID obrigatório para criar eventos.");
  const auth = await getGoogleAuthClient();
  const calendar = google.calendar({ version: "v3", auth });
  const event = {
    summary,
    description,
    start: { dateTime: startDateTime },
    end: { dateTime: endDateTime },
    attendees: attendees.map(email => ({ email }))
  };
  const res = await calendar.events.insert({
    calendarId: CALENDAR_ID,
    resource: event,
    sendUpdates: "all"
  });
  return res.data;
}

// Estado simples em memória (migrar para Redis em produção)
const conv = new Map();

function menu(name) {
  return `Olá ${name || ""} 👋
Escolha uma opção:
1 - Agendar consulta
2 - Falar com atendente
3 - Localização / Endereço

Responda apenas com o número. Digite MENU para voltar.`.trim();
}

// Webhook verify
app.get("/webhook", (req, res) => {
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];
  if (mode && token === VERIFY_TOKEN) return res.status(200).send(challenge);
  return res.sendStatus(403);
});

// Webhook receive
app.post("/webhook", async (req, res) => {
  try {
    const body = req.body;
    if (!body.object) return res.sendStatus(200);

    for (const entry of body.entry || []) {
      for (const change of entry.changes || []) {
        const value = change.value || {};
        const messages = value.messages || [];
        const contacts = value.contacts || [];

        for (const m of messages) {
          const from = m.from;
          const contact = contacts.find(c => c.wa_id === from) || {};
          const name = contact.profile?.name || "";
          const text = (m.text?.body || "").trim();

          if (!conv.has(from)) conv.set(from, { step: "menu", draft: {} });
          const state = conv.get(from);

          if (text.toLowerCase() === "menu" || text === "0") {
            conv.set(from, { step: "menu", draft: {} });
            await sendText(from, menu(name));
            continue;
          }

          if (state.step === "menu") {
            if (text === "1") {
              state.step = "ask_name";
              await sendText(from, "Ótimo! Vamos agendar. Qual seu nome completo?");
            } else if (text === "2") {
              await sendText(from, "Um atendente humano entrará em contato em breve. Digite MENU para voltar.");
              const note = `Solicitação de atendimento humano de ${name || from} (WhatsApp: ${from}).`;
              await notifySlack(note);
              await sendEmail("Atendimento humano solicitado - Clínica Blanquer", note);
            } else if (text === "3") {
              await sendText(from, "📍 Clínica Blanquer Saúde Integrativa\nAv. Paulista, 807 — São Paulo/SP\n👉 Ver no Google Maps: https://www.google.com/maps/search/?api=1&query=Av+Paulista+807+S%C3%A3o+Paulo\n\nDigite MENU para voltar.");
            } else {
              await sendText(from, menu(name));
            }
          } else if (state.step === "ask_name") {
            state.draft.name = text;
            state.step = "ask_date";
            await sendText(from, `Perfeito, ${text}. Qual data você prefere? (AAAA-MM-DD, ex: 2025-11-05)`);
          } else if (state.step === "ask_date") {
            const d = dayjs.tz(text, "YYYY-MM-DD", DEFAULT_TZ, true);
            if (!d.isValid() || d.isBefore(dayjs().tz(DEFAULT_TZ).startOf("day"))) {
              await sendText(from, "Data inválida ou no passado. Envie no formato AAAA-MM-DD e escolha uma data futura.");
            } else {
              state.draft.date = text;
              state.step = "ask_time";
              await sendText(from, "Qual horário você prefere? (HH:MM, ex: 14:30)");
            }
          } else if (state.step === "ask_time") {
            const t = dayjs(text, "HH:mm", true);
            if (!t.isValid()) {
              await sendText(from, "Horário inválido. Envie no formato HH:MM (ex: 09:30).");
            } else {
              state.draft.time = text;
              state.step = "confirm";
              const { name: nm, date, time } = state.draft;
              await sendText(from, `Confirma o agendamento?\nNome: ${nm}\nData: ${date}\nHora: ${time}\nResponda S para confirmar ou N para cancelar.`);
            }
          } else if (state.step === "confirm") {
            const ans = text.toLowerCase();
            if (ans === "s" || ans === "sim") {
              const { name: nm, date, time } = state.draft;
              const start = dayjs.tz(`${date} ${time}`, "YYYY-MM-DD HH:mm", DEFAULT_TZ);
              const end = start.add(45, "minute");
              try {
                if (CALENDAR_ID && (SERVICE_ACCOUNT_KEY || (GOOGLE_CLIENT_ID && GOOGLE_CLIENT_SECRET && GOOGLE_REFRESH_TOKEN))) {
                  const event = await createCalendarEvent({
                    summary: `Consulta - Clínica Blanquer (${nm})`,
                    description: `Agendamento via WhatsApp. Paciente: ${nm}. Telefone: ${from}`,
                    startDateTime: start.toISOString(),
                    endDateTime: end.toISOString(),
                    attendees: []
                  });
                  await sendText(from, `✔️ Agendamento confirmado!\nData: ${date}\nHora: ${time}\nID do evento: ${event.id}\n\nDigite MENU para voltar.`);
                  await notifySlack(`Novo agendamento: ${nm} - ${date} ${time} (EventoID: ${event.id})`);
                  await sendEmail("Novo agendamento - Clínica Blanquer", `Cliente: ${nm}\nTelefone: ${from}\nData: ${date}\nHora: ${time}\n`);
                } else {
                  await sendText(from, `✔️ Agendamento confirmado!\nData: ${date}\nHora: ${time}\n(Obs: Integração com Google Calendar ainda não configurada.)\n\nDigite MENU para voltar.`);
                }
              } catch (e) {
                console.error("Erro ao criar evento:", e.message);
                await sendText(from, "Desculpe, ocorreu um erro ao agendar no calendário. Tente mais tarde ou digite MENU.");
              }
              conv.delete(from);
            } else if (ans === "n" || ans === "não" || ans === "nao") {
              await sendText(from, "Agendamento cancelado. Digite MENU para voltar.");
              conv.delete(from);
            } else {
              await sendText(from, "Resposta inválida. Responda S para confirmar ou N para cancelar.");
            }
          }
        }
      }
    }
    res.sendStatus(200);
  } catch (err) {
    console.error("Erro no webhook:", err);
    res.sendStatus(500);
  }
});

app.get("/", (req, res) => res.send("Clínica Blanquer - WhatsApp Bot ativo."));
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
