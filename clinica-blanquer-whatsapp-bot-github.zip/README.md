# Clínica Blanquer – WhatsApp Bot (Cloud API Meta)

Bot oficial da Clínica Blanquer em Node.js/Express, pronto para **deploy via Railway** a partir do GitHub.
Inclui menu (Agendar / Atendente / Localização), fuso `America/Sao_Paulo`, notificações por e-mail/Slack e integração **opcional** com Google Calendar.

## Passo a passo (sem programar)
1. Acesse GitHub → **+ New repository** → Nome: `clinica-blanquer-whatsapp-bot` → **Private** → Create.
2. Clique em **Add file → Upload files** e envie estes arquivos do ZIP: `index.js`, `package.json`, `.env.example`, `README.md` → **Commit changes**.
3. Acesse o Railway → **New Project → Deploy from GitHub Repo** → selecione `clinica-blanquer-whatsapp-bot`.
4. Em **Variables**, copie os campos do `.env.example` e cole os valores:
   - `WHATSAPP_TOKEN` (Meta) • `PHONE_ID` (Meta) • `VERIFY_TOKEN=blanquer123` • `PORT=3000`
   - (Opcional) SMTP e Slack para notificações
   - (Opcional) Google Calendar
5. Ao finalizar o deploy, copie a URL do Railway e configure no Meta → **WhatsApp → Webhooks**:
   - Callback URL: `https://SUA-URL-DO-RAILWAY/webhook`
   - Verify token: `blanquer123`

### Teste
Envie mensagem para o número configurado e você verá o menu:
```
1) Agendar consulta
2) Falar com atendente
3) Localização
```

### Dicas
- Para Google Calendar, informe `CALENDAR_ID` e credenciais (OAuth2 ou Service Account).
- Para produção, troque o estado em memória por Redis.
